from brain_games.games.even_logic import even


def main():
    even()


if __name__ == '__main__':
    main()
